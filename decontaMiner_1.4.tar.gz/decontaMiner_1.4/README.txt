# The decontaMiner pipeline
# Copyright (C) 2015-2017,  M. Sangiovanni and Ilaria Granata,  ICAR-CNR, Napoli 
# 
# Authors: dr. Mara Sangiovanni -  mara.sangiovanni@icar.cnr.it
#          dr. Ilaria Granata   -  ilaria.granata@icar.cnr.it
#
#
# Please refer to the pdf UserGuide document for details about installation and usage
# the decontaMiner user guide is available online at http://www-labgtp.na.icar.cnr.it/decontaminer/
